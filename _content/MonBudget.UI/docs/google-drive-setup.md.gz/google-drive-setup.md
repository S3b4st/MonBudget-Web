# Configuration Google Drive pour MonBudget Web

Créer un projet Google Cloud, activer **Google Drive API**, configurer l’écran de consentement OAuth et ajouter les comptes de test pendant le développement. Créer ensuite un client OAuth de type **Application Web** et inscrire les origines JavaScript autorisées exactes.

Pour GitHub Pages, ajouter `https://s3b4st.github.io` aux origines du client OAuth. L’origine ne contient pas le chemin `/MonBudget-Web/`. Renseigner le client ID public dans `GoogleDrive:WebClientId` de `MonBudget.Web/wwwroot/appsettings.json`.

Le navigateur utilise Google Identity Services et demande les portées `https://www.googleapis.com/auth/drive.appdata` et `https://www.googleapis.com/auth/drive.file`. L’autorisation interactive démarre après un clic; le jeton d’accès reste en mémoire de page. Ne jamais publier de client secret, clé privée ou refresh token.

Le stockage local du navigateur reste disponible hors ligne. Les commandes Google Drive permettent de synchroniser et de restaurer une copie JSON. Le contenu est vérifié avant une restauration confirmée, et une copie de récupération protège les données locales durant l’import.

Références : [Google Drive appDataFolder](https://developers.google.com/workspace/drive/api/guides/appdata), [Google Identity Services pour le Web](https://developers.google.com/identity/oauth2/web/guides/overview).
