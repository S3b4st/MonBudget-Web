# Configuration Google Drive pour MonBudget

## Google Cloud

Créer un projet Google Cloud, activer **Google Drive API**, configurer l'écran de consentement OAuth et ajouter des comptes de test pendant le développement. MonBudget demande uniquement la portée `https://www.googleapis.com/auth/drive.appdata` et conserve `monbudget-backup.json` dans le dossier privé `appDataFolder`.

Ne jamais placer de client secret, secret de service, clé privée ou refresh token dans l'application, le dépôt ou un fichier publié. Le client ID est public.

## WebAssembly

Créer un client OAuth de type **Application Web** et inscrire les origines exactes de développement et de production comme origines JavaScript autorisées. Renseigner son client ID dans `GoogleDrive:WebClientId` de `MonBudget.Web/wwwroot/appsettings.json`. Le flux Google Identity Services s'ouvre après une action de l'utilisateur; le jeton d'accès reste seulement en mémoire de page.

## MAUI Android

Créer un client OAuth Android avec le package `ca.monbudget.app` et le SHA-1 des certificats debug/release. Le fournisseur MAUI utilise l'AuthorizationClient de Google Play Services et demande uniquement `drive.appdata`. Le compte et l'autorisation sont réutilisés quand Google le permet; aucun jeton permanent ou secret n'est écrit dans le code.

## iOS (préparation)

Créer le client OAuth iOS associé au bundle ID lors de l'activation de la cible. Le contrat `IGoogleDriveTokenProvider` est prêt à recevoir le fournisseur natif iOS; ce fournisseur n'est pas encore activé.

## Fonctionnement

La copie locale demeure la source principale. Sur Android, la copie initiale est créée après autorisation et les changements locaux sont synchronisés en arrière-plan. Une divergence de version suspend l'envoi et préserve la copie locale. La restauration ou le remplacement initial d'une sauvegarde existante exige une confirmation. Web conserve sa sauvegarde manuelle dans `localStorage`.

Références : [Drive appDataFolder](https://developers.google.com/workspace/drive/api/guides/appdata), [Google AuthorizationClient Android](https://developer.android.com/identity/authorization), [Google Identity Services Web](https://developers.google.com/identity/oauth2/web/guides/overview).
